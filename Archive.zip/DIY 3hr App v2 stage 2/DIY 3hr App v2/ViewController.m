//
//  ViewController.m
//  DIY 3hr App v2
//
//  Created by Aditya Narayan on 11/21/13.
//  Copyright (c) 2013 Aditya Narayan. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad
{
    
    
    
    [super viewDidLoad];
    
    int TOTAL_PHOTOS = 11;
    
    photoList =  [@[@"0.jpg",   @"1.jpg",   @"2.jpg",   @"3.jpg",   @"4.jpg",   @"5.jpg",   @"6.jpg",   @"7.jpg",   @"8.jpg",   @"9.jpg",   @"10.jpg"] retain];
    
    answerList = [@[@NO,        @YES,       @YES,       @YES,       @YES,       @YES,       @YES,       @YES,       @YES,       @NO,        @NO ] retain];
    
    questionNumber = 0; totalPhotos = TOTAL_PHOTOS;
    
    //Audio setup
    NSBundle *bundle = [NSBundle mainBundle];
    NSString *soundPathApplause = [bundle pathForResource:@"applause" ofType:@"wav"];
    NSString *soundPathOO =  [bundle pathForResource:@"uh-oh" ofType:@"wav"];
    
    AudioServicesCreateSystemSoundID((CFURLRef)[NSURL fileURLWithPath:soundPathApplause], &soundIDApplause);
    AudioServicesCreateSystemSoundID((CFURLRef)[NSURL fileURLWithPath:soundPathOO], &soundIDOO);

    
    
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (void)dealloc {
    [_imageHolder release];

    [_answerSelector release];
    [_scoreLabel release];
    [_gameOverMessage release];
    [super dealloc];
}


// This block of code is called each time a user selects an answer

- (IBAction)answerSelected:(UISegmentedControl *)answerSelectorControl {
    
    NSLog(@"Answwer selected");
    
    //1. Get the correct answer for the question ( from answerList above)
    
    //2. Get the user's selection from UI (0 for NYC, 1 for Not in NYC)
    
    //3. Convert from a 0/1 to YES/NO
    
    //4.Compare with correct answer
    
    //5. If answer is OK, add +1 to score, update score on screen, and applause!
    
    
    // 6. Answer not correct
    
    
    //7. Check if game over
    
    
    //8. Show next photo if game is not over
   
    
    
}



@end
